# GVariant Python Utilities

This project provides a comprehensive toolkit for working with GVariant type strings and value representations within Python. It allows for the bidirectional conversion between GVariant type signatures, GVariant text formats (gschema compatible), and native Python objects.

---

## Features

* **Type Parsing**: Converts GVariant type strings (e.g., `a{sv}`) into standard Python `typing` hints.
* **Value Conversion**: Parses GVariant text literals into coerced Python types based on a provided signature.
* **GSchema Serialization**: Serializes Python objects into strings compatible with GVariant text format and `glib-compile-schemas`.
* **Recursive Support**: Handles nested containers including arrays, tuples, dictionaries, and "maybe" types up to the GVariant limit of 65 levels.

---

## Core Components

### 1. GVariantParser

The parser implements a recursive descent strategy to interpret GVariant type signatures. It maps basic GVariant characters to Python types and handles complex container definitions.

| GVariant Character | Python Type | Description |
| --- | --- | --- |
| `b` | `bool` | Boolean |
| `s`, `o`, `g` | `str` | String, Object Path, or Signature |
| `y`, `n`, `i`, `x` | `int` | Various width signed integers |
| `q`, `u`, `t` | `int` | Various width unsigned integers |
| `d` | `float` | Double precision floating point |
| `a` | `List[T]` | Array of type T |
| `m` | `Optional[T]` | Maybe/Nullable type T |
| `()` | `Tuple[...]` | Fixed-size tuple |
| `{}` | `Dict[K, V]` | Dictionary entry (usually within an array) |
| `v`, `*`, `?` | `Any` | Indefinite or variant types |

### 2. GVariantValueConverter

This utility takes a string representation of a value and a GVariant type string. It uses `ast.literal_eval` for safe structural parsing and then recursively coerces the data into the target Python types. It specifically handles GVariant-specific keywords like `nothing` for null values and `true`/`false` for booleans.

### 3. GVariantSerializer

The serializer ensures that Python data structures are converted back into strings that the `gschema` compiler can understand. This includes converting Python's `True` to `true`, `None` to `nothing`, and ensuring correct bracket usage for arrays and dictionaries.

---

## Usage Examples

### Parsing Type Strings

```python
from gvariant_utils import GVariantParser

parser = GVariantParser()
python_type = parser.parse("a{si}") 
# Result: typing.Dict[str, int]

```

### Converting String Literals to Python Objects

```python
from gvariant_utils import GVariantValueConverter

converter = GVariantValueConverter()
value = converter.parse_value_string("[1, 2, 3]", "ai")
# Result: [1, 2, 3] (as a list of integers)

maybe_val = converter.parse_value_string("nothing", "ms")
# Result: None

```

### Serializing to GSchema Format

```python
from gvariant_utils import GVariantSerializer

data = {"enabled": True, "timeout": 30}
gschema_string = GVariantSerializer.serialize(data)
# Result: '{"enabled": true, "timeout": 30}'

```

---

## Technical Specifications

* **Nesting Limit**: Following the D-Bus and GVariant specifications, this implementation supports a recursion depth of up to 65 levels.
* **Basic Type Restriction**: In accordance with the GVariant spec, dictionary keys (the first element in `{}`) are restricted to basic types to ensure hashability.
* **Indefinite Types**: Types such as `v` (variant) and `*` (any) are mapped to Python's `Any` type, as their specific structure is determined at runtime rather than by the signature.

---

## Implementation Notes

The implementation relies on the Python `typing` module for type representation and the `ast` module for secure evaluation of string literals. It avoids the use of `eval()`, making it safe for use with untrusted input strings.
